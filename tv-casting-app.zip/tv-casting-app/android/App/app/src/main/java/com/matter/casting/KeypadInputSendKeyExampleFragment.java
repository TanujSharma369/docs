/*
 *   Copyright (c) 2024 Project CHIP Authors
 *   All rights reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package com.matter.casting;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import chip.devicecontroller.ChipClusters;
import com.R;
import com.matter.casting.core.CastingPlayer;
import com.matter.casting.core.Endpoint;
import java.util.List;

/** Fragment for sending KeypadInput commands to the casting target */
public class KeypadInputSendKeyExampleFragment extends Fragment {
  private static final String TAG = KeypadInputSendKeyExampleFragment.class.getSimpleName();
  private static final Integer KEYPAD_INPUT_CLUSTER_ID = 0x0509;

  private final CastingPlayer selectedCastingPlayer;

  private View.OnClickListener backButtonClickListener;

  public KeypadInputSendKeyExampleFragment(CastingPlayer selectedCastingPlayer) {
    this.selectedCastingPlayer = selectedCastingPlayer;
  }

  public static KeypadInputSendKeyExampleFragment newInstance(CastingPlayer selectedCastingPlayer) {
    return new KeypadInputSendKeyExampleFragment(selectedCastingPlayer);
  }

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
  }

  @Override
  public View onCreateView(
      LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    this.backButtonClickListener =
        v -> {
          Callback callback = (Callback) getActivity();
          callback.handleBackButtonClick();
        };

    return inflater.inflate(R.layout.fragment_matter_keypad_input_send_key, container, false);
  }

  @Override
  public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
    super.onViewCreated(view, savedInstanceState);
    Log.d(TAG, "KeypadInputSendKeyExampleFragment.onViewCreated called");

    TextView endpointTextView = getView().findViewById(R.id.keypadInputEndpointInfo);

    // Find endpoint with KeypadInput cluster
    Endpoint targetEndpoint = null;
    List<Endpoint> endpoints = selectedCastingPlayer.getEndpoints();
    for (Endpoint endpoint : endpoints) {
      if (endpoint.hasCluster(KEYPAD_INPUT_CLUSTER_ID)) {
        targetEndpoint = endpoint;
        break;
      }
    }

    if (targetEndpoint == null) {
      endpointTextView.setText("No endpoint with KeypadInput cluster found");
      return;
    }

    final Endpoint keypadEndpoint = targetEndpoint;
    endpointTextView.setText("Using Endpoint: " + keypadEndpoint.getId());

    // Set up button click listeners for common remote control keys
    setupKeyButton(R.id.keyUpButton, (byte) 0x01, "Up");
    setupKeyButton(R.id.keyDownButton, (byte) 0x02, "Down");
    setupKeyButton(R.id.keyLeftButton, (byte) 0x03, "Left");
    setupKeyButton(R.id.keyRightButton, (byte) 0x04, "Right");
    setupKeyButton(R.id.keySelectButton, (byte) 0x00, "Select");
    setupKeyButton(R.id.keyBackButton, (byte) 0x0D, "Exit/Back");
    setupKeyButton(R.id.keyHomeButton, (byte) 0x60, "Home");

    // Number keys
    setupKeyButton(R.id.key0Button, (byte) 0x20, "0");
    setupKeyButton(R.id.key1Button, (byte) 0x21, "1");
    setupKeyButton(R.id.key2Button, (byte) 0x22, "2");
    setupKeyButton(R.id.key3Button, (byte) 0x23, "3");
    setupKeyButton(R.id.key4Button, (byte) 0x24, "4");
    setupKeyButton(R.id.key5Button, (byte) 0x25, "5");
    setupKeyButton(R.id.key6Button, (byte) 0x26, "6");
    setupKeyButton(R.id.key7Button, (byte) 0x27, "7");
    setupKeyButton(R.id.key8Button, (byte) 0x28, "8");
    setupKeyButton(R.id.key9Button, (byte) 0x29, "9");

    getView().findViewById(R.id.backButton).setOnClickListener(backButtonClickListener);
  }

  private void setupKeyButton(int buttonId, byte keyCode, String keyName) {
    Button button = getView().findViewById(buttonId);
    if (button != null) {
      button.setOnClickListener(v -> sendKey(keyCode, keyName));
    }
  }

  private void sendKey(byte keyCode, String keyName) {
    Log.d(TAG, "Sending key: " + keyName + " (0x" + String.format("%02X", keyCode) + ")");

    TextView statusView = getView().findViewById(R.id.keypadInputStatus);
    statusView.setText("Sending: " + keyName + "...");

    // Find endpoint with KeypadInput cluster
    Endpoint targetEndpoint = null;
    List<Endpoint> endpoints = selectedCastingPlayer.getEndpoints();
    for (Endpoint endpoint : endpoints) {
      if (endpoint.hasCluster(KEYPAD_INPUT_CLUSTER_ID)) {
        targetEndpoint = endpoint;
        break;
      }
    }

    if (targetEndpoint == null) {
      statusView.setText("ERROR: No KeypadInput endpoint");
      return;
    }

    // Get ChipClusters.KeypadInputCluster from the endpoint
    ChipClusters.KeypadInputCluster cluster =
        targetEndpoint.getCluster(ChipClusters.KeypadInputCluster.class);
    if (cluster == null) {
      Log.e(TAG, "Could not get KeypadInputCluster for endpoint with ID: " + targetEndpoint.getId());
      statusView.setText("ERROR: No KeypadInput cluster");
      return;
    }

    // Call sendKey on the cluster object
    cluster.sendKey(
        new ChipClusters.KeypadInputCluster.SendKeyResponseCallback() {
          @Override
          public void onSuccess(Integer status) {
            Log.d(TAG, "SendKey success for " + keyName + ". Status: " + status);
            new Handler(Looper.getMainLooper())
                .post(
                    () -> {
                      TextView statusResult = getView().findViewById(R.id.keypadInputStatus);
                      statusResult.setText("✓ " + keyName + " (status: " + status + ")");
                    });
          }

          @Override
          public void onError(Exception error) {
            Log.e(TAG, "SendKey failure for " + keyName + ": " + error);
            new Handler(Looper.getMainLooper())
                .post(
                    () -> {
                      TextView statusResult = getView().findViewById(R.id.keypadInputStatus);
                      statusResult.setText("✗ Error: " + error.getMessage());
                    });
          }
        },
        keyCode);
  }

  /** Interface for notifying the host. */
  public interface Callback {
    /** Notifies listener to trigger transition on click of the Back button */
    void handleBackButtonClick();
  }
}
