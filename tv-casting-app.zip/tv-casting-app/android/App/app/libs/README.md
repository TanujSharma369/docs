This directory will contain any .jar files required by the TV Casting demo app
for Android.
