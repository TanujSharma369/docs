This directory will contain .so files required by TV Casting demo app for
Android. The .so files must be organized into folders by the name of the
corresponding Android architecture for which they are built, eg. arm64-v8a, x86,
x86_64, etc.
