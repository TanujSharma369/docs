package com.matter.casting;

import android.app.Application;

public class ChipTvCastingApplication extends Application {
  @Override
  public void onCreate() {
    super.onCreate();
  }
}
