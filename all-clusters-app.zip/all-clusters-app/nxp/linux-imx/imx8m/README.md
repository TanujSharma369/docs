To cross-compile this example on x64 host and run on **NXP i.MX 8M Mini**
**EVK**, see the associated
[README document](../../../../../docs/platforms/nxp/nxp_imx8m_linux_examples.md)
for details.
